<?php
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) {
    redirect('/modules/dashboard/');
} else {
    redirect('/login.php');
}
