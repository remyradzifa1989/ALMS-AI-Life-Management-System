<?php
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) redirect('/modules/dashboard/');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim($_POST['email'] ?? '');
    $pass = $_POST['password'] ?? '';
    if (login($email, $pass)) {
        redirect('/modules/dashboard/');
    }
    $error = 'Email atau password salah.';
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login | <?= APP_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="<?= APP_URL ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="brand-icon"><i class="fas fa-brain"></i></div>
    <h2>ALMS</h2>
    <p class="subtitle">AI Life Management System</p>
    <?php if ($error): ?><div class="alert alert-danger small"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
      <?= csrf_field() ?>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" required autofocus value="admin@alms.local">
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required value="admin123">
      </div>
      <button class="btn btn-primary w-100"><i class="fas fa-sign-in-alt"></i> Log Masuk</button>
    </form>
    <p class="text-center mt-3 mb-0 small">Tiada akaun? <a href="<?= APP_URL ?>/register.php">Daftar</a></p>
    <p class="text-center mt-2 small text-muted">Demo: admin@alms.local / admin123</p>
  </div>
</div>
</body>
</html>
