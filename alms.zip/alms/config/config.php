<?php
// ==========================================
// ALMS - Configuration File
// ==========================================

// Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'alms_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// App
define('APP_NAME', 'AI Life Management System');
define('APP_URL', 'http://localhost/alms');
define('APP_TIMEZONE', 'Asia/Kuala_Lumpur');

// API Keys (isi jika anda nak guna AI features)
define('OPENAI_API_KEY', ''); // sk-xxxxx untuk AI Assistant
define('OCR_API_KEY', 'helloworld'); // ocr.space free key (helloworld = demo)

// Upload
define('UPLOAD_PATH', __DIR__ . '/../assets/uploads/');
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10MB

// Security
define('CSRF_SECRET', 'change-this-random-string-in-production-please-12345');

date_default_timezone_set(APP_TIMEZONE);
session_start();
