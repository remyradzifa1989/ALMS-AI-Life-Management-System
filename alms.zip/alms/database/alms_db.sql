-- ============================================
-- ALMS Database Schema
-- ============================================
SET FOREIGN_KEY_CHECKS=0;

CREATE DATABASE IF NOT EXISTS alms_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE alms_db;

-- Users
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','user') DEFAULT 'user',
  phone VARCHAR(20),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Finance: income & expense
DROP TABLE IF EXISTS finance_records;
CREATE TABLE finance_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type ENUM('income','expense','saving','debt','loan','investment') NOT NULL,
  category VARCHAR(100),
  amount DECIMAL(12,2) NOT NULL,
  description VARCHAR(255),
  record_date DATE NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Budgets
DROP TABLE IF EXISTS budgets;
CREATE TABLE budgets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  category VARCHAR(100) NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  month VARCHAR(7) NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Bills
DROP TABLE IF EXISTS bills;
CREATE TABLE bills (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type ENUM('elektrik','air','internet','telefon','astro','cukai','lain') NOT NULL,
  account_no VARCHAR(100),
  amount DECIMAL(12,2) NOT NULL,
  bill_date DATE,
  due_date DATE,
  status ENUM('belum','dibayar') DEFAULT 'belum',
  notes VARCHAR(255),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Documents
DROP TABLE IF EXISTS documents;
CREATE TABLE documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  category ENUM('ic','sijil_lahir','passport','lesen','takaful','geran','rumah','perniagaan','lain') NOT NULL,
  title VARCHAR(255) NOT NULL,
  file_path VARCHAR(255) NOT NULL,
  file_type VARCHAR(50),
  tags VARCHAR(255),
  notes TEXT,
  uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Vehicles
DROP TABLE IF EXISTS vehicles;
CREATE TABLE vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  plate_no VARCHAR(20) NOT NULL,
  brand VARCHAR(100),
  model VARCHAR(100),
  year INT,
  roadtax_expiry DATE,
  takaful_expiry DATE,
  last_service DATE,
  next_service DATE,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Vehicle records
DROP TABLE IF EXISTS vehicle_records;
CREATE TABLE vehicle_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  vehicle_id INT NOT NULL,
  type ENUM('servis','kemalangan','saman') NOT NULL,
  record_date DATE,
  amount DECIMAL(12,2),
  description TEXT,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Family members
DROP TABLE IF EXISTS family_members;
CREATE TABLE family_members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(150) NOT NULL,
  relationship VARCHAR(50),
  birth_date DATE,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Family events
DROP TABLE IF EXISTS family_events;
CREATE TABLE family_events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  member_id INT,
  type ENUM('sekolah','klinik','aktiviti','lain') DEFAULT 'aktiviti',
  title VARCHAR(255) NOT NULL,
  event_date DATETIME NOT NULL,
  location VARCHAR(255),
  notes TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (member_id) REFERENCES family_members(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Ibadah
DROP TABLE IF EXISTS ibadah_records;
CREATE TABLE ibadah_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type ENUM('solat','puasa','sedekah','zakat','quran') NOT NULL,
  detail VARCHAR(255),
  amount DECIMAL(12,2) DEFAULT 0,
  record_date DATE NOT NULL,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Notifications
DROP TABLE IF EXISTS notifications;
CREATE TABLE notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT,
  type VARCHAR(50),
  is_read TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- AI Chat history
DROP TABLE IF EXISTS ai_chats;
CREATE TABLE ai_chats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  role ENUM('user','assistant') NOT NULL,
  message TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- Default users (password: admin123 / user123)
-- ============================================
INSERT INTO users (name,email,password,role) VALUES
('Admin ALMS','admin@alms.local','$2y$10$.yCr7Sqkvwb3kge.KG4q0OcocQZEE0oBZvkLsMiOEBCOn6x.MMBfm','admin'),
('Pengguna Demo','user@alms.local','$2y$10$.6D1BFdWYrl5336XDD7nLuxBKRTRd3dha5G0wjeqktz/pTI8rLMdy','user');

-- Sample finance
INSERT INTO finance_records (user_id,type,category,amount,description,record_date) VALUES
(2,'income','Gaji',5000,'Gaji bulanan',CURDATE()),
(2,'expense','Makanan',350,'Groceries',CURDATE()),
(2,'expense','Pengangkutan',200,'Minyak kereta',CURDATE());

INSERT INTO bills (user_id,type,account_no,amount,bill_date,due_date,status) VALUES
(2,'elektrik','TNB-12345',180.50,CURDATE(),DATE_ADD(CURDATE(),INTERVAL 7 DAY),'belum'),
(2,'internet','UNIFI-99887',129.00,CURDATE(),DATE_ADD(CURDATE(),INTERVAL 15 DAY),'belum');

INSERT INTO vehicles (user_id,plate_no,brand,model,year,roadtax_expiry,takaful_expiry) VALUES
(2,'VBB 1234','Perodua','Myvi',2020,DATE_ADD(CURDATE(),INTERVAL 25 DAY),DATE_ADD(CURDATE(),INTERVAL 60 DAY));

SET FOREIGN_KEY_CHECKS=1;
