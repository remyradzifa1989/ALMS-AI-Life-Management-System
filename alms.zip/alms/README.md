# AI Life Management System (ALMS)

Sistem pengurusan kehidupan digital berasaskan PHP Native + MySQL.

## Keperluan
- XAMPP (Apache + MySQL + PHP 7.4 atau lebih tinggi)
- Browser moden

## Pemasangan di XAMPP localhost

1. **Extract ZIP** ini ke dalam folder `htdocs` XAMPP:
   ```
   C:\xampp\htdocs\alms
   ```

2. **Start Apache + MySQL** dari XAMPP Control Panel.

3. **Import database**:
   - Buka `http://localhost/phpmyadmin`
   - Klik **New** → buat database nama `alms_db`
   - Pilih database `alms_db` → tab **Import**
   - Pilih fail `database/alms_db.sql` → **Go**

4. **Konfigurasi** (jika perlu):
   - Edit `config/config.php` jika nama database / user MySQL anda berbeza.
   - Untuk AI Smart Scan & AI Assistant, tambah API key:
     ```php
     define('OPENAI_API_KEY', 'sk-xxxxx');
     define('OCR_API_KEY', 'xxxxx'); // ocr.space free key
     ```

5. **Akses sistem**:
   ```
   http://localhost/alms
   ```

6. **Login default**:
   - Admin: `admin@alms.local` / `admin123`
   - User: `user@alms.local` / `user123`

## Struktur Folder

```
alms/
├── config/          # Konfigurasi database & app
├── includes/        # Header, footer, auth, helper functions
├── assets/          # CSS, JS, uploads (dokumen & resit)
├── modules/         # 10 modul utama
│   ├── dashboard/
│   ├── finance/
│   ├── bills/
│   ├── scan/
│   ├── documents/
│   ├── vehicles/
│   ├── family/
│   ├── ibadah/
│   ├── assistant/
│   └── notifications/
├── admin/           # Panel admin
├── api/             # API endpoints (OCR, AI chat)
├── database/        # SQL schema
├── index.php        # Entry point
├── login.php
├── register.php
└── logout.php
```

## Modul
1. Dashboard — ringkasan semua modul
2. Pengurusan Kewangan — pendapatan, perbelanjaan, bajet, chart
3. Pengurusan Bil — elektrik, air, internet, dll
4. AI Smart Scan — OCR resit/bil (perlu OCR API key)
5. Pengurusan Dokumen Digital — IC, sijil, polisi
6. Pengurusan Kenderaan — roadtax, takaful, servis
7. Pengurusan Keluarga — ahli, jadual, kalendar
8. Pengurusan Ibadah — solat, puasa, sedekah, zakat
9. AI Assistant — chat (perlu OpenAI API key)
10. Notifikasi Pintar — reminder bil/roadtax/temujanji

## Keselamatan
- Session authentication
- CSRF token pada semua form
- Password hashing (bcrypt)
- PDO prepared statements (anti SQL injection)
- htmlspecialchars (anti XSS)

## Lesen
Bebas digunakan untuk projek peribadi/komersial.
