<?php
$pageTitle = 'Pengurusan Dokumen Digital';
require_once __DIR__ . '/../../includes/header.php';
$uid = current_user_id();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    if (isset($_POST['delete'])) {
        $s = db()->prepare("SELECT file_path FROM documents WHERE id=? AND user_id=?");
        $s->execute([$_POST['delete'], $uid]);
        if ($row = $s->fetch()) {
            @unlink(UPLOAD_PATH . $row['file_path']);
            db()->prepare("DELETE FROM documents WHERE id=? AND user_id=?")->execute([$_POST['delete'], $uid]);
            flash('success','Dokumen dipadam.');
        }
    } elseif (isset($_FILES['file']) && $_FILES['file']['error']===0) {
        $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','pdf','docx','xlsx'])) {
            $newName = 'doc_' . $uid . '_' . time() . '.' . $ext;
            if (!is_dir(UPLOAD_PATH)) mkdir(UPLOAD_PATH, 0777, true);
            move_uploaded_file($_FILES['file']['tmp_name'], UPLOAD_PATH . $newName);
            $s = db()->prepare("INSERT INTO documents (user_id,category,title,file_path,file_type,tags,notes) VALUES (?,?,?,?,?,?,?)");
            $s->execute([$uid, $_POST['category'], $_POST['title'], $newName, $ext, $_POST['tags'], $_POST['notes']]);
            flash('success','Dokumen dimuat naik.');
        } else flash('error','Format tidak disokong.');
    }
    redirect('/modules/documents/');
}

$q = trim($_GET['q'] ?? '');
$sql = "SELECT * FROM documents WHERE user_id=?";
$params = [$uid];
if ($q) { $sql .= " AND (title LIKE ? OR tags LIKE ? OR category LIKE ?)"; $params = array_merge($params, ["%$q%","%$q%","%$q%"]); }
$sql .= " ORDER BY uploaded_at DESC";
$st = db()->prepare($sql); $st->execute($params); $docs = $st->fetchAll();

$cats = ['ic'=>'Kad Pengenalan','sijil_lahir'=>'Sijil Lahir','passport'=>'Passport','lesen'=>'Lesen Memandu','takaful'=>'Polisi Takaful','geran'=>'Geran Kenderaan','rumah'=>'Dokumen Rumah','perniagaan'=>'Dokumen Perniagaan','lain'=>'Lain-lain'];
?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="alms-card">
      <h6><i class="fas fa-cloud-upload-alt"></i> Upload Dokumen</h6>
      <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="mb-2"><label class="form-label small">Kategori</label>
          <select name="category" class="form-select form-select-sm" required>
            <?php foreach ($cats as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?>
          </select></div>
        <div class="mb-2"><label class="form-label small">Tajuk</label><input name="title" class="form-control form-control-sm" required></div>
        <div class="mb-2"><label class="form-label small">Tag (dipisah dgn koma)</label><input name="tags" class="form-control form-control-sm" placeholder="penting, 2024"></div>
        <div class="mb-2"><label class="form-label small">Nota</label><textarea name="notes" class="form-control form-control-sm" rows="2"></textarea></div>
        <div class="mb-2"><label class="form-label small">Fail</label><input type="file" name="file" class="form-control form-control-sm" required></div>
        <button class="btn btn-primary btn-sm w-100">Upload</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="alms-card">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="mb-0"><i class="fas fa-folder-open"></i> Senarai Dokumen</h6>
        <form class="d-flex" method="get"><input name="q" value="<?= e($q) ?>" placeholder="Cari…" class="form-control form-control-sm"><button class="btn btn-sm btn-outline-primary ms-1"><i class="fas fa-search"></i></button></form>
      </div>
      <div class="row g-2">
        <?php foreach ($docs as $d): ?>
          <div class="col-md-6">
            <div class="border rounded p-3 d-flex align-items-center gap-3">
              <div class="text-primary fs-2"><i class="fas fa-file-<?= in_array($d['file_type'],['jpg','jpeg','png'])?'image':($d['file_type']=='pdf'?'pdf':'alt') ?>"></i></div>
              <div class="flex-grow-1 min-w-0">
                <div class="fw-semibold text-truncate"><?= e($d['title']) ?></div>
                <small class="text-muted d-block"><?= $cats[$d['category']]??$d['category'] ?> · <?= date('d/m/y',strtotime($d['uploaded_at'])) ?></small>
                <?php if ($d['tags']): ?><small class="text-info"><?= e($d['tags']) ?></small><?php endif; ?>
              </div>
              <div class="d-flex flex-column gap-1">
                <a href="<?= APP_URL ?>/assets/uploads/<?= e($d['file_path']) ?>" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i></a>
                <form method="post" onsubmit="return confirmDelete()"><?= csrf_field() ?><input type="hidden" name="delete" value="<?= $d['id'] ?>"><button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button></form>
              </div>
            </div>
          </div>
        <?php endforeach; if(!$docs): ?><div class="col-12 text-center text-muted py-4">Tiada dokumen.</div><?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
