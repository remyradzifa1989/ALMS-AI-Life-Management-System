<?php
$pageTitle = 'Notifikasi Pintar';
require_once __DIR__ . '/../../includes/header.php';
$uid = current_user_id();

// Auto-generate notifications based on data
$notifs = [];

// Bills due soon
$s = db()->prepare("SELECT * FROM bills WHERE user_id=? AND status='belum' AND due_date <= DATE_ADD(CURDATE(),INTERVAL 7 DAY)");
$s->execute([$uid]);
foreach ($s->fetchAll() as $b) {
    $days = max(0, (int)((strtotime($b['due_date'])-time())/86400));
    $notifs[] = ['type'=>'danger','icon'=>'file-invoice-dollar','title'=>"Bil $b[type] (RM ".number_format($b['amount'],2).")",'msg'=>"Tarikh akhir: ".date('d/m/Y',strtotime($b['due_date']))." — $days hari lagi"];
}

// Roadtax / takaful
$s = db()->prepare("SELECT * FROM vehicles WHERE user_id=? AND (roadtax_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY) OR takaful_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY))");
$s->execute([$uid]);
foreach ($s->fetchAll() as $v) {
    if ($v['roadtax_expiry'] && strtotime($v['roadtax_expiry'])-time() <= 30*86400) {
        $notifs[] = ['type'=>'warning','icon'=>'car','title'=>"Roadtax $v[plate_no] hampir tamat",'msg'=>"Tarikh: ".date('d/m/Y',strtotime($v['roadtax_expiry']))];
    }
    if ($v['takaful_expiry'] && strtotime($v['takaful_expiry'])-time() <= 30*86400) {
        $notifs[] = ['type'=>'warning','icon'=>'shield-alt','title'=>"Takaful $v[plate_no] hampir tamat",'msg'=>"Tarikh: ".date('d/m/Y',strtotime($v['takaful_expiry']))];
    }
}

// Family events upcoming
$s = db()->prepare("SELECT * FROM family_events WHERE user_id=? AND event_date BETWEEN NOW() AND DATE_ADD(NOW(),INTERVAL 7 DAY)");
$s->execute([$uid]);
foreach ($s->fetchAll() as $ev) {
    $notifs[] = ['type'=>'info','icon'=>'calendar','title'=>"Temujanji: $ev[title]",'msg'=>date('d/m/Y h:i A',strtotime($ev['event_date']))." @ ".($ev['location']?:'—')];
}

if (!$notifs) $notifs[] = ['type'=>'success','icon'=>'check-circle','title'=>'Semua terkawal','msg'=>'Tiada peringatan mendesak buat masa ini. ✅'];
?>
<div class="alms-card">
  <h6><i class="fas fa-bell text-warning"></i> Peringatan Aktif</h6>
  <?php foreach ($notifs as $n): ?>
    <div class="d-flex align-items-start py-3 border-bottom">
      <div class="icon icon-<?= $n['type']=='danger'?'danger':($n['type']=='warning'?'warning':($n['type']=='info'?'info':'success')) ?> me-3"><i class="fas fa-<?= $n['icon'] ?>"></i></div>
      <div class="flex-grow-1"><div class="fw-semibold"><?= e($n['title']) ?></div><small class="text-muted"><?= e($n['msg']) ?></small></div>
    </div>
  <?php endforeach; ?>
</div>

<div class="alms-card">
  <h6><i class="fas fa-cog"></i> Saluran Notifikasi</h6>
  <div class="row g-3">
    <div class="col-md-4"><div class="border rounded p-3 text-center"><i class="fas fa-desktop fa-2x text-primary mb-2"></i><h6>Dashboard</h6><span class="badge bg-success">Aktif</span></div></div>
    <div class="col-md-4"><div class="border rounded p-3 text-center"><i class="fas fa-envelope fa-2x text-warning mb-2"></i><h6>Email</h6><span class="badge bg-secondary">Perlu Setup SMTP</span></div></div>
    <div class="col-md-4"><div class="border rounded p-3 text-center"><i class="fab fa-whatsapp fa-2x text-success mb-2"></i><h6>WhatsApp</h6><span class="badge bg-secondary">Perlu API Key</span></div></div>
  </div>
  <p class="small text-muted mt-3 mb-0">Untuk Email dan WhatsApp, anda perlu setup PHPMailer + SMTP credentials atau guna API seperti CallMeBot/Twilio WhatsApp.</p>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
