<?php
$pageTitle = 'Pengurusan Ibadah';
require_once __DIR__ . '/../../includes/header.php';
$uid = current_user_id();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    if (isset($_POST['delete'])) {
        db()->prepare("DELETE FROM ibadah_records WHERE id=? AND user_id=?")->execute([$_POST['delete'], $uid]);
        flash('success','Rekod dipadam.');
    } else {
        $s = db()->prepare("INSERT INTO ibadah_records (user_id,type,detail,amount,record_date,notes) VALUES (?,?,?,?,?,?)");
        $s->execute([$uid, $_POST['type'], $_POST['detail'], $_POST['amount'] ?: 0, $_POST['record_date'], $_POST['notes']]);
        flash('success','Rekod ibadah disimpan.');
    }
    redirect('/modules/ibadah/');
}

$month = date('Y-m');
$stats = db()->prepare("SELECT type, COUNT(*) cnt, SUM(amount) total FROM ibadah_records WHERE user_id=? AND DATE_FORMAT(record_date,'%Y-%m')=? GROUP BY type");
$stats->execute([$uid, $month]);
$stats = $stats->fetchAll(PDO::FETCH_UNIQUE);

$records = db()->prepare("SELECT * FROM ibadah_records WHERE user_id=? ORDER BY record_date DESC LIMIT 50");
$records->execute([$uid]); $records = $records->fetchAll();

$types = ['solat'=>['Solat','fa-pray','primary'],'puasa'=>['Puasa','fa-moon','info'],'sedekah'=>['Sedekah','fa-hand-holding-heart','success'],'zakat'=>['Zakat','fa-coins','warning'],'quran'=>['Bacaan Quran','fa-book-quran','danger']];
?>
<div class="row g-3 mb-3">
  <?php foreach ($types as $k=>$t): ?>
    <div class="col-md col-6"><div class="stat-card"><div class="icon icon-<?= $t[2] ?>"><i class="fas <?= $t[1] ?>"></i></div><div class="label"><?= $t[0] ?></div><div class="value"><?= $stats[$k]['cnt']??0 ?> <?php if($k=='sedekah'||$k=='zakat'): ?><small class="text-muted fs-6">RM<?= number_format($stats[$k]['total']??0,0) ?></small><?php endif; ?></div></div></div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="alms-card"><h6><i class="fas fa-plus-circle"></i> Rekod Ibadah</h6>
      <form method="post"><?= csrf_field() ?>
        <div class="mb-2"><label class="form-label small">Jenis</label>
          <select name="type" class="form-select form-select-sm" required>
            <?php foreach ($types as $k=>$t): ?><option value="<?= $k ?>"><?= $t[0] ?></option><?php endforeach; ?>
          </select></div>
        <div class="mb-2"><label class="form-label small">Butiran</label><input name="detail" class="form-control form-control-sm" placeholder="Subuh / 5 mukasurat / Tabung"></div>
        <div class="mb-2"><label class="form-label small">Amaun (jika sedekah/zakat)</label><input name="amount" type="number" step="0.01" class="form-control form-control-sm" value="0"></div>
        <div class="mb-2"><label class="form-label small">Tarikh</label><input type="date" name="record_date" class="form-control form-control-sm" value="<?= date('Y-m-d') ?>" required></div>
        <div class="mb-2"><label class="form-label small">Nota</label><textarea name="notes" class="form-control form-control-sm" rows="2"></textarea></div>
        <button class="btn btn-primary btn-sm w-100">Simpan</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="alms-card"><h6><i class="fas fa-history"></i> Rekod Terkini</h6>
      <div class="table-responsive"><table class="table table-hover">
        <thead><tr><th>Tarikh</th><th>Jenis</th><th>Butiran</th><th class="text-end">Amaun</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($records as $r): ?>
          <tr>
            <td><?= date('d/m/y',strtotime($r['record_date'])) ?></td>
            <td><span class="badge bg-<?= $types[$r['type']][2]??'secondary' ?>"><?= $types[$r['type']][0]??$r['type'] ?></span></td>
            <td><?= e($r['detail']) ?></td>
            <td class="text-end"><?= $r['amount']>0?'RM '.number_format($r['amount'],2):'—' ?></td>
            <td><form method="post" onsubmit="return confirmDelete()"><?= csrf_field() ?><input type="hidden" name="delete" value="<?= $r['id'] ?>"><button class="btn btn-sm btn-link text-danger p-0"><i class="fas fa-trash"></i></button></form></td>
          </tr>
        <?php endforeach; if(!$records): ?><tr><td colspan="5" class="text-center text-muted py-3">Tiada rekod.</td></tr><?php endif; ?>
        </tbody>
      </table></div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
