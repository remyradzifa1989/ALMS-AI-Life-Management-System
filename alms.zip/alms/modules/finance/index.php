<?php
$pageTitle = 'Pengurusan Kewangan';
require_once __DIR__ . '/../../includes/header.php';
$uid = current_user_id();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    if (isset($_POST['delete'])) {
        $s = db()->prepare("DELETE FROM finance_records WHERE id=? AND user_id=?");
        $s->execute([$_POST['delete'], $uid]);
        flash('success','Rekod dipadam.');
    } else {
        $s = db()->prepare("INSERT INTO finance_records (user_id,type,category,amount,description,record_date) VALUES (?,?,?,?,?,?)");
        $s->execute([$uid, $_POST['type'], $_POST['category'], $_POST['amount'], $_POST['description'], $_POST['record_date']]);
        flash('success','Rekod ditambah.');
    }
    redirect('/modules/finance/');
}

$records = db()->prepare("SELECT * FROM finance_records WHERE user_id=? ORDER BY record_date DESC, id DESC LIMIT 50");
$records->execute([$uid]);
$records = $records->fetchAll();

$month = date('Y-m');
$summary = db()->prepare("SELECT type, COALESCE(SUM(amount),0) total FROM finance_records WHERE user_id=? AND DATE_FORMAT(record_date,'%Y-%m')=? GROUP BY type");
$summary->execute([$uid, $month]);
$summary = $summary->fetchAll(PDO::FETCH_KEY_PAIR);
?>
<div class="row g-3 mb-3">
  <div class="col-md-3 col-6"><div class="stat-card"><div class="label">Pendapatan</div><div class="value text-success">RM <?= number_format($summary['income']??0,2) ?></div></div></div>
  <div class="col-md-3 col-6"><div class="stat-card"><div class="label">Perbelanjaan</div><div class="value text-danger">RM <?= number_format($summary['expense']??0,2) ?></div></div></div>
  <div class="col-md-3 col-6"><div class="stat-card"><div class="label">Simpanan</div><div class="value text-info">RM <?= number_format($summary['saving']??0,2) ?></div></div></div>
  <div class="col-md-3 col-6"><div class="stat-card"><div class="label">Pelaburan</div><div class="value text-primary">RM <?= number_format($summary['investment']??0,2) ?></div></div></div>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="alms-card">
      <h6><i class="fas fa-plus-circle"></i> Tambah Rekod</h6>
      <form method="post">
        <?= csrf_field() ?>
        <div class="mb-2"><label class="form-label small">Jenis</label>
          <select name="type" class="form-select form-select-sm" required>
            <option value="income">Pendapatan</option><option value="expense">Perbelanjaan</option>
            <option value="saving">Simpanan</option><option value="debt">Hutang</option>
            <option value="loan">Pinjaman</option><option value="investment">Pelaburan</option>
          </select></div>
        <div class="mb-2"><label class="form-label small">Kategori</label><input name="category" class="form-control form-control-sm" placeholder="Gaji / Makanan / Bil…" required></div>
        <div class="mb-2"><label class="form-label small">Amaun (RM)</label><input name="amount" type="number" step="0.01" class="form-control form-control-sm" required></div>
        <div class="mb-2"><label class="form-label small">Keterangan</label><input name="description" class="form-control form-control-sm"></div>
        <div class="mb-2"><label class="form-label small">Tarikh</label><input name="record_date" type="date" class="form-control form-control-sm" value="<?= date('Y-m-d') ?>" required></div>
        <button class="btn btn-primary btn-sm w-100">Simpan</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="alms-card">
      <h6><i class="fas fa-list"></i> Senarai Rekod Terkini</h6>
      <div class="table-responsive">
      <table class="table table-hover">
        <thead><tr><th>Tarikh</th><th>Jenis</th><th>Kategori</th><th>Keterangan</th><th class="text-end">Amaun</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($records as $r): $cls=['income'=>'success','expense'=>'danger','saving'=>'info','debt'=>'warning','loan'=>'warning','investment'=>'primary'][$r['type']]; ?>
          <tr>
            <td><?= date('d/m/y',strtotime($r['record_date'])) ?></td>
            <td><span class="badge bg-<?= $cls ?>"><?= ucfirst($r['type']) ?></span></td>
            <td><?= e($r['category']) ?></td>
            <td><?= e($r['description']) ?></td>
            <td class="text-end fw-semibold">RM <?= number_format($r['amount'],2) ?></td>
            <td><form method="post" onsubmit="return confirmDelete()" class="d-inline"><?= csrf_field() ?><input type="hidden" name="delete" value="<?= $r['id'] ?>"><button class="btn btn-sm btn-link text-danger p-0"><i class="fas fa-trash"></i></button></form></td>
          </tr>
        <?php endforeach; if (!$records): ?><tr><td colspan="6" class="text-center text-muted py-3">Tiada rekod.</td></tr><?php endif; ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
