<?php
$pageTitle = 'Pengurusan Kenderaan';
require_once __DIR__ . '/../../includes/header.php';
$uid = current_user_id();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    if (isset($_POST['delete'])) {
        db()->prepare("DELETE FROM vehicles WHERE id=? AND user_id=?")->execute([$_POST['delete'], $uid]);
        flash('success','Kenderaan dipadam.');
    } else {
        $s = db()->prepare("INSERT INTO vehicles (user_id,plate_no,brand,model,year,roadtax_expiry,takaful_expiry,last_service,next_service,notes) VALUES (?,?,?,?,?,?,?,?,?,?)");
        $s->execute([$uid, $_POST['plate_no'], $_POST['brand'], $_POST['model'], $_POST['year'] ?: null,
            $_POST['roadtax_expiry'] ?: null, $_POST['takaful_expiry'] ?: null,
            $_POST['last_service'] ?: null, $_POST['next_service'] ?: null, $_POST['notes']]);
        flash('success','Kenderaan ditambah.');
    }
    redirect('/modules/vehicles/');
}

$vehicles = db()->prepare("SELECT * FROM vehicles WHERE user_id=? ORDER BY id DESC");
$vehicles->execute([$uid]);
$vehicles = $vehicles->fetchAll();
?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="alms-card">
      <h6><i class="fas fa-plus-circle"></i> Tambah Kenderaan</h6>
      <form method="post">
        <?= csrf_field() ?>
        <div class="mb-2"><label class="form-label small">No Plat</label><input name="plate_no" class="form-control form-control-sm" required></div>
        <div class="row g-2 mb-2">
          <div class="col-6"><label class="form-label small">Brand</label><input name="brand" class="form-control form-control-sm"></div>
          <div class="col-6"><label class="form-label small">Model</label><input name="model" class="form-control form-control-sm"></div>
        </div>
        <div class="mb-2"><label class="form-label small">Tahun</label><input type="number" name="year" class="form-control form-control-sm"></div>
        <div class="mb-2"><label class="form-label small">Roadtax Tamat</label><input type="date" name="roadtax_expiry" class="form-control form-control-sm"></div>
        <div class="mb-2"><label class="form-label small">Takaful Tamat</label><input type="date" name="takaful_expiry" class="form-control form-control-sm"></div>
        <div class="row g-2 mb-2">
          <div class="col-6"><label class="form-label small">Servis Lalu</label><input type="date" name="last_service" class="form-control form-control-sm"></div>
          <div class="col-6"><label class="form-label small">Servis Akan</label><input type="date" name="next_service" class="form-control form-control-sm"></div>
        </div>
        <div class="mb-2"><label class="form-label small">Catatan</label><textarea name="notes" class="form-control form-control-sm" rows="2"></textarea></div>
        <button class="btn btn-primary btn-sm w-100">Simpan</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="row g-3">
      <?php foreach ($vehicles as $v): 
        $rtDays = $v['roadtax_expiry'] ? (strtotime($v['roadtax_expiry'])-time())/86400 : null;
        $tkDays = $v['takaful_expiry'] ? (strtotime($v['takaful_expiry'])-time())/86400 : null;
      ?>
        <div class="col-md-6">
          <div class="alms-card mb-0">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <div>
                <h5 class="mb-0"><?= e($v['plate_no']) ?></h5>
                <small class="text-muted"><?= e($v['brand']) ?> <?= e($v['model']) ?> · <?= e($v['year']) ?></small>
              </div>
              <form method="post" onsubmit="return confirmDelete()"><?= csrf_field() ?><input type="hidden" name="delete" value="<?= $v['id'] ?>"><button class="btn btn-sm btn-link text-danger"><i class="fas fa-trash"></i></button></form>
            </div>
            <hr class="my-2">
            <div class="small">
              <div class="d-flex justify-content-between py-1"><span class="text-muted">Roadtax:</span><span><?= $v['roadtax_expiry']?date('d/m/Y',strtotime($v['roadtax_expiry'])):'—' ?> <?php if($rtDays!==null && $rtDays<30): ?><span class="badge bg-warning text-dark ms-1"><?= max(0,(int)$rtDays) ?>h</span><?php endif; ?></span></div>
              <div class="d-flex justify-content-between py-1"><span class="text-muted">Takaful:</span><span><?= $v['takaful_expiry']?date('d/m/Y',strtotime($v['takaful_expiry'])):'—' ?> <?php if($tkDays!==null && $tkDays<30): ?><span class="badge bg-warning text-dark ms-1"><?= max(0,(int)$tkDays) ?>h</span><?php endif; ?></span></div>
              <div class="d-flex justify-content-between py-1"><span class="text-muted">Servis Akan Datang:</span><span><?= $v['next_service']?date('d/m/Y',strtotime($v['next_service'])):'—' ?></span></div>
            </div>
          </div>
        </div>
      <?php endforeach; if(!$vehicles): ?><div class="col-12"><div class="alms-card text-center text-muted">Tiada kenderaan didaftarkan.</div></div><?php endif; ?>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
