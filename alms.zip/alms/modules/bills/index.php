<?php
$pageTitle = 'Pengurusan Bil';
require_once __DIR__ . '/../../includes/header.php';
$uid = current_user_id();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    if (isset($_POST['delete'])) {
        $s = db()->prepare("DELETE FROM bills WHERE id=? AND user_id=?");
        $s->execute([$_POST['delete'], $uid]);
        flash('success','Bil dipadam.');
    } elseif (isset($_POST['pay'])) {
        $s = db()->prepare("UPDATE bills SET status='dibayar' WHERE id=? AND user_id=?");
        $s->execute([$_POST['pay'], $uid]);
        flash('success','Bil ditanda sebagai dibayar.');
    } else {
        $s = db()->prepare("INSERT INTO bills (user_id,type,account_no,amount,bill_date,due_date,notes) VALUES (?,?,?,?,?,?,?)");
        $s->execute([$uid, $_POST['type'], $_POST['account_no'], $_POST['amount'], $_POST['bill_date'], $_POST['due_date'], $_POST['notes']]);
        flash('success','Bil ditambah.');
    }
    redirect('/modules/bills/');
}

$bills = db()->prepare("SELECT * FROM bills WHERE user_id=? ORDER BY status ASC, due_date ASC");
$bills->execute([$uid]);
$bills = $bills->fetchAll();
?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="alms-card">
      <h6><i class="fas fa-plus-circle"></i> Tambah Bil</h6>
      <form method="post">
        <?= csrf_field() ?>
        <div class="mb-2"><label class="form-label small">Jenis Bil</label>
          <select name="type" class="form-select form-select-sm" required>
            <option value="elektrik">Elektrik (TNB)</option><option value="air">Air</option>
            <option value="internet">Internet</option><option value="telefon">Telefon</option>
            <option value="astro">Astro</option><option value="cukai">Cukai</option>
            <option value="lain">Lain-lain</option>
          </select></div>
        <div class="mb-2"><label class="form-label small">No Akaun</label><input name="account_no" class="form-control form-control-sm"></div>
        <div class="mb-2"><label class="form-label small">Amaun (RM)</label><input name="amount" type="number" step="0.01" class="form-control form-control-sm" required></div>
        <div class="mb-2"><label class="form-label small">Tarikh Bil</label><input name="bill_date" type="date" class="form-control form-control-sm" value="<?= date('Y-m-d') ?>"></div>
        <div class="mb-2"><label class="form-label small">Tarikh Akhir Bayaran</label><input name="due_date" type="date" class="form-control form-control-sm" required></div>
        <div class="mb-2"><label class="form-label small">Catatan</label><input name="notes" class="form-control form-control-sm"></div>
        <button class="btn btn-primary btn-sm w-100">Simpan</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="alms-card">
      <h6><i class="fas fa-file-invoice-dollar"></i> Senarai Bil</h6>
      <div class="table-responsive">
      <table class="table table-hover">
        <thead><tr><th>Jenis</th><th>Akaun</th><th class="text-end">Amaun</th><th>Tarikh Akhir</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($bills as $b): $diff = (strtotime($b['due_date']) - time())/86400; ?>
          <tr>
            <td><span class="badge bg-secondary"><?= e(ucfirst($b['type'])) ?></span></td>
            <td><?= e($b['account_no']) ?></td>
            <td class="text-end fw-semibold">RM <?= number_format($b['amount'],2) ?></td>
            <td><?= date('d/m/y',strtotime($b['due_date'])) ?> <?php if ($b['status']==='belum' && $diff<7): ?><small class="text-danger d-block">⚠️ <?= max(0,(int)$diff) ?> hari lagi</small><?php endif; ?></td>
            <td><?php if ($b['status']==='dibayar'): ?><span class="badge bg-success">Dibayar</span><?php else: ?><span class="badge bg-warning text-dark">Belum</span><?php endif; ?></td>
            <td>
              <?php if ($b['status']==='belum'): ?>
                <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="pay" value="<?= $b['id'] ?>"><button class="btn btn-sm btn-success" title="Tanda dibayar"><i class="fas fa-check"></i></button></form>
              <?php endif; ?>
              <form method="post" onsubmit="return confirmDelete()" class="d-inline"><?= csrf_field() ?><input type="hidden" name="delete" value="<?= $b['id'] ?>"><button class="btn btn-sm btn-link text-danger p-0"><i class="fas fa-trash"></i></button></form>
            </td>
          </tr>
        <?php endforeach; if(!$bills): ?><tr><td colspan="6" class="text-center text-muted py-3">Tiada bil.</td></tr><?php endif; ?>
        </tbody>
      </table></div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
