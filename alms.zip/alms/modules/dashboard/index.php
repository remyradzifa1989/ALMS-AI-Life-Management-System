<?php
$pageTitle = 'Dashboard';
require_once __DIR__ . '/../../includes/header.php';
$uid = current_user_id();
$month = date('Y-m');

// Stats
$income = db()->prepare("SELECT COALESCE(SUM(amount),0) FROM finance_records WHERE user_id=? AND type='income' AND DATE_FORMAT(record_date,'%Y-%m')=?");
$income->execute([$uid, $month]);
$incomeTotal = $income->fetchColumn();

$expense = db()->prepare("SELECT COALESCE(SUM(amount),0) FROM finance_records WHERE user_id=? AND type='expense' AND DATE_FORMAT(record_date,'%Y-%m')=?");
$expense->execute([$uid, $month]);
$expenseTotal = $expense->fetchColumn();

$unpaidBills = db()->prepare("SELECT COUNT(*),COALESCE(SUM(amount),0) FROM bills WHERE user_id=? AND status='belum'");
$unpaidBills->execute([$uid]);
$bills = $unpaidBills->fetch(PDO::FETCH_NUM);

$roadtaxSoon = db()->prepare("SELECT COUNT(*) FROM vehicles WHERE user_id=? AND roadtax_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)");
$roadtaxSoon->execute([$uid]);
$rtCount = $roadtaxSoon->fetchColumn();

$takafulSoon = db()->prepare("SELECT COUNT(*) FROM vehicles WHERE user_id=? AND takaful_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)");
$takafulSoon->execute([$uid]);
$tkCount = $takafulSoon->fetchColumn();

$famEvents = db()->prepare("SELECT * FROM family_events WHERE user_id=? AND event_date>=NOW() ORDER BY event_date ASC LIMIT 5");
$famEvents->execute([$uid]);
$famEvents = $famEvents->fetchAll();

$ibadahCount = db()->prepare("SELECT COUNT(*) FROM ibadah_records WHERE user_id=? AND DATE_FORMAT(record_date,'%Y-%m')=?");
$ibadahCount->execute([$uid, $month]);
$ibadahCount = $ibadahCount->fetchColumn();

// chart data - last 6 months expenses by category
$chartData = db()->prepare("SELECT category, SUM(amount) total FROM finance_records WHERE user_id=? AND type='expense' AND record_date>=DATE_SUB(CURDATE(),INTERVAL 30 DAY) GROUP BY category");
$chartData->execute([$uid]);
$chartData = $chartData->fetchAll();
?>
<div class="row g-3 mb-3">
  <div class="col-md-3 col-6"><div class="stat-card"><div class="icon icon-success"><i class="fas fa-arrow-down"></i></div><div class="label">Pendapatan Bulan Ini</div><div class="value">RM <?= number_format($incomeTotal,2) ?></div></div></div>
  <div class="col-md-3 col-6"><div class="stat-card"><div class="icon icon-danger"><i class="fas fa-arrow-up"></i></div><div class="label">Perbelanjaan Bulan Ini</div><div class="value">RM <?= number_format($expenseTotal,2) ?></div></div></div>
  <div class="col-md-3 col-6"><div class="stat-card"><div class="icon icon-warning"><i class="fas fa-file-invoice"></i></div><div class="label">Bil Belum Bayar</div><div class="value"><?= $bills[0] ?? 0 ?> <small class="text-muted fs-6">/ RM<?= number_format($bills[1]??0,2) ?></small></div></div></div>
  <div class="col-md-3 col-6"><div class="stat-card"><div class="icon icon-info"><i class="fas fa-pray"></i></div><div class="label">Rekod Ibadah</div><div class="value"><?= $ibadahCount ?></div></div></div>
</div>

<div class="row g-3 mb-3">
  <div class="col-md-3 col-6"><div class="stat-card"><div class="icon icon-warning"><i class="fas fa-car"></i></div><div class="label">Roadtax Hampir Tamat (30 hari)</div><div class="value"><?= $rtCount ?></div></div></div>
  <div class="col-md-3 col-6"><div class="stat-card"><div class="icon icon-warning"><i class="fas fa-shield-alt"></i></div><div class="label">Takaful Hampir Tamat</div><div class="value"><?= $tkCount ?></div></div></div>
  <div class="col-md-6"><div class="stat-card"><div class="icon icon-primary"><i class="fas fa-piggy-bank"></i></div><div class="label">Baki Bulan Ini (Pendapatan − Perbelanjaan)</div><div class="value">RM <?= number_format($incomeTotal-$expenseTotal,2) ?></div></div></div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="alms-card">
      <h6><i class="fas fa-chart-pie text-primary"></i> Perbelanjaan Mengikut Kategori (30 hari)</h6>
      <canvas id="catChart" height="180"></canvas>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="alms-card">
      <h6><i class="fas fa-calendar-check text-primary"></i> Aktiviti Keluarga Akan Datang</h6>
      <?php if (!$famEvents): ?>
        <p class="text-muted small mb-0">Tiada aktiviti dirancang.</p>
      <?php else: foreach ($famEvents as $ev): ?>
        <div class="d-flex border-bottom py-2"><div class="me-3 text-center"><div class="fw-bold text-primary"><?= date('d',strtotime($ev['event_date'])) ?></div><small class="text-muted"><?= date('M',strtotime($ev['event_date'])) ?></small></div><div><div class="fw-semibold"><?= e($ev['title']) ?></div><small class="text-muted"><?= date('h:i A',strtotime($ev['event_date'])) ?> · <?= e($ev['location']?:'—') ?></small></div></div>
      <?php endforeach; endif; ?>
    </div>
    <div class="alms-card">
      <h6><i class="fas fa-lightbulb text-warning"></i> AI Insight</h6>
      <p class="small mb-1"><?php
        if ($expenseTotal > $incomeTotal) echo "⚠️ Perbelanjaan anda melebihi pendapatan bulan ini. Pertimbangkan untuk kurangkan perbelanjaan tidak perlu.";
        elseif ($expenseTotal > $incomeTotal*0.8) echo "💡 Perbelanjaan anda hampir mencecah 80% pendapatan. Tingkatkan tabungan.";
        else echo "✅ Kewangan anda terkawal bulan ini. Teruskan!";
      ?></p>
      <?php if ($rtCount>0): ?><p class="small mb-0 text-warning">🚗 Ada <?= $rtCount ?> roadtax akan tamat dalam 30 hari.</p><?php endif; ?>
    </div>
  </div>
</div>

<script>
const ctx = document.getElementById('catChart');
new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: <?= json_encode(array_column($chartData,'category') ?: ['Tiada Data']) ?>,
    datasets: [{
      data: <?= json_encode(array_column($chartData,'total') ?: [1]) ?>,
      backgroundColor: ['#4f46e5','#ec4899','#f59e0b','#10b981','#3b82f6','#ef4444','#8b5cf6']
    }]
  },
  options: {responsive:true, plugins:{legend:{position:'right'}}}
});
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
