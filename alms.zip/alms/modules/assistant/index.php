<?php
$pageTitle = 'AI Assistant';
require_once __DIR__ . '/../../includes/header.php';
$uid = current_user_id();

$chats = db()->prepare("SELECT * FROM ai_chats WHERE user_id=? ORDER BY created_at ASC LIMIT 50");
$chats->execute([$uid]); $chats = $chats->fetchAll();
?>
<div class="alms-card">
  <h6><i class="fas fa-robot text-primary"></i> AI Assistant — Tanya apa-apa tentang hidup digital anda</h6>
  <div class="chat-window" id="chatWindow">
    <?php if (!$chats): ?>
      <div class="text-center text-muted py-4">
        <i class="fas fa-comments fa-3x mb-3 opacity-25"></i>
        <p>Mulakan perbualan. Contoh:</p>
        <ul class="list-unstyled small">
          <li>"Berapa jumlah perbelanjaan saya bulan ini?"</li>
          <li>"Bil apa yang belum dibayar?"</li>
          <li>"Roadtax mana yang hampir tamat?"</li>
        </ul>
      </div>
    <?php endif; ?>
    <?php foreach ($chats as $c): ?>
      <div class="chat-msg <?= $c['role'] ?>"><div class="bubble"><?= nl2br(e($c['message'])) ?></div></div>
    <?php endforeach; ?>
  </div>
  <form id="chatForm" class="d-flex gap-2">
    <input type="text" id="chatInput" class="form-control" placeholder="Taip soalan anda…" autocomplete="off" required>
    <button class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
  </form>
  <p class="small text-muted mt-2 mb-0">💡 Tambah <code>OPENAI_API_KEY</code> dalam <code>config/config.php</code> untuk dayakan AI sebenar. Tanpa key, sistem guna jawapan asas berdasarkan data anda.</p>
</div>

<script>
const cw = document.getElementById('chatWindow');
cw.scrollTop = cw.scrollHeight;
document.getElementById('chatForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = document.getElementById('chatInput');
  const msg = input.value.trim();
  if (!msg) return;
  cw.innerHTML += `<div class="chat-msg user"><div class="bubble">${msg}</div></div>`;
  input.value = '';
  cw.scrollTop = cw.scrollHeight;
  const res = await fetch('<?= APP_URL ?>/api/chat.php', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({message: msg, csrf: '<?= csrf_token() ?>'})
  });
  const data = await res.json();
  cw.innerHTML += `<div class="chat-msg ai"><div class="bubble">${data.reply.replace(/\n/g,'<br>')}</div></div>`;
  cw.scrollTop = cw.scrollHeight;
});
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
