<?php
$pageTitle = 'AI Smart Scan (OCR)';
require_once __DIR__ . '/../../includes/header.php';
$uid = current_user_id();
$result = null;

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_FILES['file'])) {
    verify_csrf();
    $file = $_FILES['file'];
    if ($file['error']===0 && $file['size'] <= MAX_UPLOAD_SIZE) {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','pdf'])) {
            $newName = 'scan_' . $uid . '_' . time() . '.' . $ext;
            $dest = UPLOAD_PATH . $newName;
            if (!is_dir(UPLOAD_PATH)) mkdir(UPLOAD_PATH, 0777, true);
            move_uploaded_file($file['tmp_name'], $dest);

            // Call OCR.space API
            $ch = curl_init('https://api.ocr.space/parse/image');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_HTTPHEADER => ['apikey: ' . OCR_API_KEY],
                CURLOPT_POSTFIELDS => [
                    'file' => new CURLFile($dest),
                    'language' => 'eng',
                    'isOverlayRequired' => 'false',
                    'OCREngine' => '2',
                ],
                CURLOPT_TIMEOUT => 60,
            ]);
            $resp = curl_exec($ch);
            curl_close($ch);
            $data = json_decode($resp, true);
            $text = $data['ParsedResults'][0]['ParsedText'] ?? '';

            // Simple extraction
            $extracted = [
                'text' => $text,
                'amount' => null,
                'date' => null,
                'reference' => null,
            ];
            if (preg_match('/(RM|MYR)\s*([0-9,]+\.[0-9]{2})/i', $text, $m)) $extracted['amount'] = $m[2];
            if (preg_match('/(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/', $text, $m)) $extracted['date'] = $m[1];
            if (preg_match('/(REF|NO|INV)[:\s#]*([A-Z0-9\-]{4,})/i', $text, $m)) $extracted['reference'] = $m[2];
            $result = $extracted;
            $result['file'] = $newName;
        } else {
            flash('error','Format fail tidak disokong (jpg/png/pdf sahaja).');
        }
    } else {
        flash('error','Saiz fail terlalu besar (max 10MB).');
    }
}
?>
<div class="row g-3">
  <div class="col-lg-5">
    <div class="alms-card">
      <h6><i class="fas fa-camera"></i> Upload Dokumen / Resit</h6>
      <p class="small text-muted">AI akan mengekstrak amaun, tarikh, no rujukan secara automatik daripada resit, bil, polisi takaful, roadtax, geran, dsb.</p>
      <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="mb-3"><input type="file" name="file" class="form-control" accept=".jpg,.jpeg,.png,.pdf" required></div>
        <button class="btn btn-primary w-100"><i class="fas fa-magic"></i> Scan dengan AI</button>
      </form>
      <hr>
      <p class="small text-muted mb-1"><strong>Nota Setup:</strong></p>
      <p class="small text-muted mb-0">Dapatkan free API key di <a href="https://ocr.space/ocrapi/freekey" target="_blank">ocr.space</a> dan masukkan dalam <code>config/config.php</code> (constant <code>OCR_API_KEY</code>). Demo key "helloworld" terhad.</p>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="alms-card">
      <h6><i class="fas fa-clipboard-check"></i> Hasil Ekstrak AI</h6>
      <?php if ($result): ?>
        <div class="row g-2 mb-3">
          <div class="col-6"><div class="border rounded p-2"><small class="text-muted d-block">Amaun</small><strong><?= e($result['amount']?'RM '.$result['amount']:'—') ?></strong></div></div>
          <div class="col-6"><div class="border rounded p-2"><small class="text-muted d-block">Tarikh</small><strong><?= e($result['date']?:'—') ?></strong></div></div>
          <div class="col-12"><div class="border rounded p-2"><small class="text-muted d-block">No Rujukan</small><strong><?= e($result['reference']?:'—') ?></strong></div></div>
        </div>
        <label class="form-label small fw-semibold">Teks Penuh:</label>
        <textarea class="form-control" rows="10" readonly><?= e($result['text']) ?></textarea>
      <?php else: ?>
        <div class="text-center py-5 text-muted">
          <i class="fas fa-file-image fa-3x mb-3 opacity-25"></i>
          <p>Upload satu fail untuk mula scan.</p>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
