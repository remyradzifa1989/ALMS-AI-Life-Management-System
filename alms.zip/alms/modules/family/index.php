<?php
$pageTitle = 'Pengurusan Keluarga';
require_once __DIR__ . '/../../includes/header.php';
$uid = current_user_id();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    if (isset($_POST['add_member'])) {
        $s = db()->prepare("INSERT INTO family_members (user_id,name,relationship,birth_date,notes) VALUES (?,?,?,?,?)");
        $s->execute([$uid, $_POST['name'], $_POST['relationship'], $_POST['birth_date'] ?: null, $_POST['notes']]);
        flash('success','Ahli keluarga ditambah.');
    } elseif (isset($_POST['add_event'])) {
        $s = db()->prepare("INSERT INTO family_events (user_id,member_id,type,title,event_date,location,notes) VALUES (?,?,?,?,?,?,?)");
        $s->execute([$uid, $_POST['member_id'] ?: null, $_POST['type'], $_POST['title'], $_POST['event_date'], $_POST['location'], $_POST['notes']]);
        flash('success','Aktiviti ditambah.');
    } elseif (isset($_POST['delete_member'])) {
        db()->prepare("DELETE FROM family_members WHERE id=? AND user_id=?")->execute([$_POST['delete_member'], $uid]);
    } elseif (isset($_POST['delete_event'])) {
        db()->prepare("DELETE FROM family_events WHERE id=? AND user_id=?")->execute([$_POST['delete_event'], $uid]);
    }
    redirect('/modules/family/');
}

$members = db()->prepare("SELECT * FROM family_members WHERE user_id=? ORDER BY name");
$members->execute([$uid]); $members = $members->fetchAll();

$events = db()->prepare("SELECT e.*, m.name member_name FROM family_events e LEFT JOIN family_members m ON m.id=e.member_id WHERE e.user_id=? ORDER BY event_date ASC");
$events->execute([$uid]); $events = $events->fetchAll();
?>
<ul class="nav nav-tabs mb-3">
  <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#tab-members">Ahli Keluarga</a></li>
  <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab-events">Aktiviti & Jadual</a></li>
</ul>
<div class="tab-content">
  <div class="tab-pane fade show active" id="tab-members">
    <div class="row g-3">
      <div class="col-lg-4"><div class="alms-card"><h6><i class="fas fa-user-plus"></i> Tambah Ahli</h6>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="add_member" value="1">
          <div class="mb-2"><label class="form-label small">Nama</label><input name="name" class="form-control form-control-sm" required></div>
          <div class="mb-2"><label class="form-label small">Hubungan</label><input name="relationship" class="form-control form-control-sm" placeholder="Anak / Pasangan / Ibu"></div>
          <div class="mb-2"><label class="form-label small">Tarikh Lahir</label><input type="date" name="birth_date" class="form-control form-control-sm"></div>
          <div class="mb-2"><label class="form-label small">Catatan</label><textarea name="notes" class="form-control form-control-sm" rows="2"></textarea></div>
          <button class="btn btn-primary btn-sm w-100">Tambah</button>
        </form></div></div>
      <div class="col-lg-8"><div class="alms-card"><h6><i class="fas fa-users"></i> Senarai Ahli</h6>
        <div class="table-responsive"><table class="table table-hover">
          <thead><tr><th>Nama</th><th>Hubungan</th><th>T. Lahir</th><th>Umur</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($members as $m): ?>
            <tr><td><?= e($m['name']) ?></td><td><?= e($m['relationship']) ?></td><td><?= $m['birth_date']?date('d/m/Y',strtotime($m['birth_date'])):'—' ?></td>
              <td><?= $m['birth_date']?floor((time()-strtotime($m['birth_date']))/86400/365):'—' ?></td>
              <td><form method="post" onsubmit="return confirmDelete()"><?= csrf_field() ?><input type="hidden" name="delete_member" value="<?= $m['id'] ?>"><button class="btn btn-sm btn-link text-danger p-0"><i class="fas fa-trash"></i></button></form></td>
            </tr>
          <?php endforeach; if(!$members): ?><tr><td colspan="5" class="text-center text-muted py-3">Tiada rekod.</td></tr><?php endif; ?>
          </tbody>
        </table></div>
      </div></div>
    </div>
  </div>
  <div class="tab-pane fade" id="tab-events">
    <div class="row g-3">
      <div class="col-lg-4"><div class="alms-card"><h6><i class="fas fa-calendar-plus"></i> Tambah Aktiviti</h6>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="add_event" value="1">
          <div class="mb-2"><label class="form-label small">Jenis</label>
            <select name="type" class="form-select form-select-sm"><option value="sekolah">Sekolah</option><option value="klinik">Klinik</option><option value="aktiviti">Aktiviti</option><option value="lain">Lain</option></select></div>
          <div class="mb-2"><label class="form-label small">Untuk</label>
            <select name="member_id" class="form-select form-select-sm"><option value="">— Keluarga —</option>
            <?php foreach ($members as $m): ?><option value="<?= $m['id'] ?>"><?= e($m['name']) ?></option><?php endforeach; ?>
            </select></div>
          <div class="mb-2"><label class="form-label small">Tajuk</label><input name="title" class="form-control form-control-sm" required></div>
          <div class="mb-2"><label class="form-label small">Tarikh & Masa</label><input type="datetime-local" name="event_date" class="form-control form-control-sm" required></div>
          <div class="mb-2"><label class="form-label small">Lokasi</label><input name="location" class="form-control form-control-sm"></div>
          <div class="mb-2"><label class="form-label small">Nota</label><textarea name="notes" class="form-control form-control-sm" rows="2"></textarea></div>
          <button class="btn btn-primary btn-sm w-100">Simpan</button>
        </form></div></div>
      <div class="col-lg-8"><div class="alms-card"><h6><i class="fas fa-calendar"></i> Jadual</h6>
        <?php foreach ($events as $ev): ?>
          <div class="d-flex border-bottom py-2 align-items-center">
            <div class="me-3 text-center" style="width:60px"><div class="fw-bold text-primary fs-5"><?= date('d',strtotime($ev['event_date'])) ?></div><small class="text-muted"><?= date('M Y',strtotime($ev['event_date'])) ?></small></div>
            <div class="flex-grow-1"><div class="fw-semibold"><?= e($ev['title']) ?> <span class="badge bg-light text-dark"><?= e($ev['type']) ?></span></div><small class="text-muted"><?= date('h:i A',strtotime($ev['event_date'])) ?> · <?= e($ev['member_name']?:'Keluarga') ?> · <?= e($ev['location']?:'—') ?></small></div>
            <form method="post" onsubmit="return confirmDelete()"><?= csrf_field() ?><input type="hidden" name="delete_event" value="<?= $ev['id'] ?>"><button class="btn btn-sm btn-link text-danger"><i class="fas fa-trash"></i></button></form>
          </div>
        <?php endforeach; if(!$events): ?><p class="text-center text-muted py-3 mb-0">Tiada aktiviti.</p><?php endif; ?>
      </div></div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
