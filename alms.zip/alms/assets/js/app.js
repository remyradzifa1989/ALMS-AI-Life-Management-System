// ALMS App JS
document.addEventListener('DOMContentLoaded', function () {
  // Auto-hide alerts
  document.querySelectorAll('.alert').forEach(a => {
    setTimeout(() => a.style.transition = 'opacity .5s', 100);
    setTimeout(() => a.style.opacity = 0, 4000);
    setTimeout(() => a.remove(), 4500);
  });
});

function confirmDelete(msg) {
  return confirm(msg || 'Adakah anda pasti mahu padam rekod ini?');
}
