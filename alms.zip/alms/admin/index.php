<?php
$pageTitle = 'Admin Panel';
require_once __DIR__ . '/../includes/header.php';
require_admin();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    if (isset($_POST['delete_user']) && $_POST['delete_user'] != current_user_id()) {
        db()->prepare("DELETE FROM users WHERE id=?")->execute([$_POST['delete_user']]);
        flash('success','Pengguna dipadam.');
        redirect('/admin/');
    }
    if (isset($_POST['role_change'])) {
        db()->prepare("UPDATE users SET role=? WHERE id=?")->execute([$_POST['role'], $_POST['role_change']]);
        flash('success','Role dikemaskini.');
        redirect('/admin/');
    }
}

$users = db()->query("SELECT u.*, (SELECT COUNT(*) FROM finance_records WHERE user_id=u.id) finance_cnt, (SELECT COUNT(*) FROM bills WHERE user_id=u.id) bill_cnt FROM users u ORDER BY id DESC")->fetchAll();
$stats = [
    'users' => db()->query("SELECT COUNT(*) FROM users")->fetchColumn(),
    'finance' => db()->query("SELECT COUNT(*) FROM finance_records")->fetchColumn(),
    'bills' => db()->query("SELECT COUNT(*) FROM bills")->fetchColumn(),
    'docs' => db()->query("SELECT COUNT(*) FROM documents")->fetchColumn(),
];
?>
<div class="row g-3 mb-3">
  <div class="col-md-3 col-6"><div class="stat-card"><div class="label">Jumlah Pengguna</div><div class="value"><?= $stats['users'] ?></div></div></div>
  <div class="col-md-3 col-6"><div class="stat-card"><div class="label">Rekod Kewangan</div><div class="value"><?= $stats['finance'] ?></div></div></div>
  <div class="col-md-3 col-6"><div class="stat-card"><div class="label">Rekod Bil</div><div class="value"><?= $stats['bills'] ?></div></div></div>
  <div class="col-md-3 col-6"><div class="stat-card"><div class="label">Dokumen</div><div class="value"><?= $stats['docs'] ?></div></div></div>
</div>
<div class="alms-card">
  <h6><i class="fas fa-users-cog"></i> Pengurusan Pengguna</h6>
  <div class="table-responsive"><table class="table table-hover">
    <thead><tr><th>ID</th><th>Nama</th><th>Email</th><th>Role</th><th>Data</th><th>Daftar</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($users as $u): ?>
      <tr>
        <td>#<?= $u['id'] ?></td>
        <td><?= e($u['name']) ?></td>
        <td><?= e($u['email']) ?></td>
        <td><form method="post" class="d-flex gap-1"><?= csrf_field() ?><input type="hidden" name="role_change" value="<?= $u['id'] ?>">
          <select name="role" class="form-select form-select-sm"><option value="user" <?= $u['role']=='user'?'selected':'' ?>>User</option><option value="admin" <?= $u['role']=='admin'?'selected':'' ?>>Admin</option></select>
          <button class="btn btn-sm btn-outline-primary"><i class="fas fa-save"></i></button>
        </form></td>
        <td><small class="text-muted">Kewangan: <?= $u['finance_cnt'] ?> · Bil: <?= $u['bill_cnt'] ?></small></td>
        <td><?= date('d/m/y',strtotime($u['created_at'])) ?></td>
        <td><?php if ($u['id'] != current_user_id()): ?>
          <form method="post" onsubmit="return confirmDelete('Padam pengguna dan semua data?')"><?= csrf_field() ?><input type="hidden" name="delete_user" value="<?= $u['id'] ?>"><button class="btn btn-sm btn-link text-danger p-0"><i class="fas fa-trash"></i></button></form>
        <?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
