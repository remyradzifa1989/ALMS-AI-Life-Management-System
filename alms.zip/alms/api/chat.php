<?php
// AI Chat API endpoint
require_once __DIR__ . '/../includes/auth.php';
require_login();
header('Content-Type: application/json');

$body = json_decode(file_get_contents('php://input'), true);
$msg = trim($body['message'] ?? '');
if (!$msg) { echo json_encode(['reply'=>'Sila taip mesej.']); exit; }

$uid = current_user_id();
db()->prepare("INSERT INTO ai_chats (user_id,role,message) VALUES (?,?,?)")->execute([$uid,'user',$msg]);

// Context from user data
$ctx = [];
$s = db()->prepare("SELECT type, COALESCE(SUM(amount),0) t FROM finance_records WHERE user_id=? AND DATE_FORMAT(record_date,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m') GROUP BY type");
$s->execute([$uid]);
foreach ($s->fetchAll() as $r) $ctx[] = ucfirst($r['type']).": RM".number_format($r['t'],2);

$s = db()->prepare("SELECT COUNT(*) c, COALESCE(SUM(amount),0) t FROM bills WHERE user_id=? AND status='belum'");
$s->execute([$uid]); $bill = $s->fetch();
$ctx[] = "Bil belum bayar: $bill[c] (RM".number_format($bill['t'],2).")";

$s = db()->prepare("SELECT plate_no, roadtax_expiry FROM vehicles WHERE user_id=? AND roadtax_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 60 DAY)");
$s->execute([$uid]);
foreach ($s->fetchAll() as $v) $ctx[] = "Roadtax $v[plate_no] tamat ".$v['roadtax_expiry'];

$context = implode("\n", $ctx);
$reply = '';

if (OPENAI_API_KEY && strlen(OPENAI_API_KEY) > 10) {
    // Real OpenAI call
    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . OPENAI_API_KEY],
        CURLOPT_POSTFIELDS => json_encode([
            'model' => 'gpt-4o-mini',
            'messages' => [
                ['role'=>'system','content'=>"Kamu adalah AI Assistant untuk sistem ALMS. Jawab dalam Bahasa Melayu. Data semasa pengguna:\n$context"],
                ['role'=>'user','content'=>$msg]
            ],
        ]),
        CURLOPT_TIMEOUT => 30,
    ]);
    $resp = json_decode(curl_exec($ch), true);
    curl_close($ch);
    $reply = $resp['choices'][0]['message']['content'] ?? 'Maaf, AI tidak dapat menjawab buat masa ini.';
} else {
    // Fallback rule-based
    $low = strtolower($msg);
    if (strpos($low,'belanja')!==false || strpos($low,'perbelanjaan')!==false) {
        $r = db()->prepare("SELECT COALESCE(SUM(amount),0) FROM finance_records WHERE user_id=? AND type='expense' AND DATE_FORMAT(record_date,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m')");
        $r->execute([$uid]);
        $reply = "Jumlah perbelanjaan anda bulan ini: RM ".number_format($r->fetchColumn(),2);
    } elseif (strpos($low,'pendapatan')!==false || strpos($low,'gaji')!==false) {
        $r = db()->prepare("SELECT COALESCE(SUM(amount),0) FROM finance_records WHERE user_id=? AND type='income' AND DATE_FORMAT(record_date,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m')");
        $r->execute([$uid]);
        $reply = "Jumlah pendapatan anda bulan ini: RM ".number_format($r->fetchColumn(),2);
    } elseif (strpos($low,'bil')!==false) {
        $r = db()->prepare("SELECT type, amount, due_date FROM bills WHERE user_id=? AND status='belum'");
        $r->execute([$uid]); $rows = $r->fetchAll();
        if (!$rows) $reply = "Tiada bil belum dibayar. 🎉";
        else { $reply = "Bil belum dibayar:\n"; foreach($rows as $b) $reply .= "• $b[type]: RM ".number_format($b['amount'],2)." (tamat $b[due_date])\n"; }
    } elseif (strpos($low,'roadtax')!==false || strpos($low,'kereta')!==false) {
        $r = db()->prepare("SELECT plate_no, roadtax_expiry FROM vehicles WHERE user_id=? ORDER BY roadtax_expiry");
        $r->execute([$uid]); $rows = $r->fetchAll();
        if (!$rows) $reply = "Tiada kenderaan didaftarkan.";
        else { $reply = "Status roadtax:\n"; foreach($rows as $v) $reply .= "• $v[plate_no]: tamat ".($v['roadtax_expiry']?:'—')."\n"; }
    } else {
        $reply = "Saya boleh bantu dengan: kewangan, bil, roadtax, ibadah. Cuba tanya:\n• Berapa perbelanjaan bulan ini?\n• Bil apa belum dibayar?\n• Roadtax mana hampir tamat?\n\n💡 Tambah OPENAI_API_KEY untuk jawapan AI penuh.";
    }
}

db()->prepare("INSERT INTO ai_chats (user_id,role,message) VALUES (?,?,?)")->execute([$uid,'assistant',$reply]);
echo json_encode(['reply' => $reply]);
