<?php
require_once __DIR__ . '/auth.php';
require_login();
$user = current_user();
$current = $_GET['module'] ?? basename(dirname($_SERVER['PHP_SELF']));
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle ?? 'ALMS') ?> | <?= APP_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="<?= APP_URL ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="alms-app">
  <!-- Sidebar -->
  <aside class="alms-sidebar" id="sidebar">
    <div class="sidebar-brand">
      <i class="fas fa-brain"></i>
      <span>ALMS</span>
    </div>
    <nav class="sidebar-nav">
      <a href="<?= APP_URL ?>/modules/dashboard/" class="<?= $current=='dashboard'?'active':'' ?>"><i class="fas fa-th-large"></i> Dashboard</a>
      <a href="<?= APP_URL ?>/modules/finance/" class="<?= $current=='finance'?'active':'' ?>"><i class="fas fa-wallet"></i> Kewangan</a>
      <a href="<?= APP_URL ?>/modules/bills/" class="<?= $current=='bills'?'active':'' ?>"><i class="fas fa-file-invoice-dollar"></i> Bil</a>
      <a href="<?= APP_URL ?>/modules/scan/" class="<?= $current=='scan'?'active':'' ?>"><i class="fas fa-camera"></i> AI Smart Scan</a>
      <a href="<?= APP_URL ?>/modules/documents/" class="<?= $current=='documents'?'active':'' ?>"><i class="fas fa-folder-open"></i> Dokumen</a>
      <a href="<?= APP_URL ?>/modules/vehicles/" class="<?= $current=='vehicles'?'active':'' ?>"><i class="fas fa-car"></i> Kenderaan</a>
      <a href="<?= APP_URL ?>/modules/family/" class="<?= $current=='family'?'active':'' ?>"><i class="fas fa-users"></i> Keluarga</a>
      <a href="<?= APP_URL ?>/modules/ibadah/" class="<?= $current=='ibadah'?'active':'' ?>"><i class="fas fa-mosque"></i> Ibadah</a>
      <a href="<?= APP_URL ?>/modules/assistant/" class="<?= $current=='assistant'?'active':'' ?>"><i class="fas fa-robot"></i> AI Assistant</a>
      <a href="<?= APP_URL ?>/modules/notifications/" class="<?= $current=='notifications'?'active':'' ?>"><i class="fas fa-bell"></i> Notifikasi</a>
      <?php if (($user['role'] ?? '') === 'admin'): ?>
      <hr class="my-2 border-secondary">
      <a href="<?= APP_URL ?>/admin/" class="<?= $current=='admin'?'active':'' ?>"><i class="fas fa-user-shield"></i> Admin Panel</a>
      <?php endif; ?>
    </nav>
  </aside>

  <!-- Main -->
  <div class="alms-main">
    <header class="alms-topbar">
      <button class="btn btn-link text-white d-md-none" onclick="document.getElementById('sidebar').classList.toggle('show')"><i class="fas fa-bars"></i></button>
      <h5 class="mb-0"><?= e($pageTitle ?? 'Dashboard') ?></h5>
      <div class="ms-auto d-flex align-items-center gap-3">
        <span class="text-muted small d-none d-md-block"><i class="far fa-clock"></i> <?= date('d M Y, h:i A') ?></span>
        <div class="dropdown">
          <button class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown">
            <i class="fas fa-user-circle"></i> <?= e($user['name']) ?>
          </button>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><span class="dropdown-item-text small text-muted"><?= e($user['email']) ?></span></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?= APP_URL ?>/logout.php"><i class="fas fa-sign-out-alt"></i> Log Keluar</a></li>
          </ul>
        </div>
      </div>
    </header>
    <main class="alms-content">
      <?php if ($msg = flash('success')): ?><div class="alert alert-success"><?= e($msg) ?></div><?php endif; ?>
      <?php if ($msg = flash('error')): ?><div class="alert alert-danger"><?= e($msg) ?></div><?php endif; ?>
