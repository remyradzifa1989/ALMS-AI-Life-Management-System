    </main>
    <footer class="alms-footer">
      &copy; <?= date('Y') ?> <?= APP_NAME ?> — Pengurusan Hidup Digital
    </footer>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="<?= APP_URL ?>/assets/js/app.js"></script>
</body>
</html>
