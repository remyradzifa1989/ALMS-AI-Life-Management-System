<?php
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) redirect('/modules/dashboard/');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pass = $_POST['password'] ?? '';
    if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 6) {
        $error = 'Sila lengkapkan semua medan dengan betul (password minimum 6 aksara).';
    } else {
        $stmt = db()->prepare("SELECT id FROM users WHERE email=?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email telah didaftarkan.';
        } else {
            $stmt = db()->prepare("INSERT INTO users (name,email,password,role,created_at) VALUES (?,?,?,?,NOW())");
            $stmt->execute([$name, $email, password_hash($pass, PASSWORD_BCRYPT), 'user']);
            flash('success', 'Pendaftaran berjaya. Sila log masuk.');
            redirect('/login.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Daftar | <?= APP_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="<?= APP_URL ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="brand-icon"><i class="fas fa-user-plus"></i></div>
    <h2>Daftar Akaun</h2>
    <p class="subtitle">Mulakan perjalanan digital anda</p>
    <?php if ($error): ?><div class="alert alert-danger small"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
      <?= csrf_field() ?>
      <div class="mb-3"><label class="form-label">Nama Penuh</label><input type="text" name="name" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required minlength="6"></div>
      <button class="btn btn-primary w-100">Daftar</button>
    </form>
    <p class="text-center mt-3 small">Sudah ada akaun? <a href="<?= APP_URL ?>/login.php">Log Masuk</a></p>
  </div>
</div>
</body>
</html>
